
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { geminiService } from '../services/geminiService';
import { RadioStation } from '../types';

interface DJHistoryEntry {
  text: string;
  timestamp: Date;
}

interface VirtualDJProps {
  currentStation: RadioStation;
}

export const VirtualDJ: React.FC<VirtualDJProps> = ({ currentStation }) => {
  const [isTalking, setIsTalking] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [history, setHistory] = useState<DJHistoryEntry[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const [isReady, setIsReady] = useState(false);

  const initAudio = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      setIsReady(true);
    }
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const numChannels = 1;
    const sampleRate = 24000;
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const handleDJBreak = useCallback(async () => {
    if (!isReady) {
      initAudio();
      // Não retorna, continua para processar se o contexto foi criado
      if (!audioContextRef.current) return;
    }
    
    setIsTalking(true);
    setTranscript("Gerando comentário do DJ...");
    
    try {
      const introText = await geminiService.generateDJIntro(currentStation.name, currentStation.genre);
      setTranscript(introText);

      const audioBytes = await geminiService.speakText(introText);
      
      if (audioBytes && audioContextRef.current) {
        const buffer = await decodeAudioData(audioBytes, audioContextRef.current);
        const source = audioContextRef.current.createBufferSource();
        source.buffer = buffer;
        source.connect(audioContextRef.current.destination);
        
        source.onended = () => {
          setIsTalking(false);
          setTranscript("");
          // Adiciona ao histórico após a fala terminar
          setHistory(prev => [{ text: introText, timestamp: new Date() }, ...prev].slice(0, 10));
        };
        
        source.start();
      } else {
        // Fallback se o áudio falhar mas o texto existir
        setTimeout(() => {
          setIsTalking(false);
          setTranscript("");
          setHistory(prev => [{ text: introText, timestamp: new Date() }, ...prev].slice(0, 10));
        }, 3000);
      }
    } catch (error) {
      console.error("DJ Break error:", error);
      setIsTalking(false);
      setTranscript("");
    }
  }, [currentStation, isReady]);

  return (
    <div className="space-y-4 mb-4">
      {/* Painel Principal do DJ */}
      <div className="bg-slate-900/50 backdrop-blur-md border border-slate-700/50 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`w-3 h-3 rounded-full ${isTalking ? 'bg-pink-500 animate-pulse shadow-[0_0_10px_rgba(236,72,153,0.5)]' : 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.3)]'}`}></div>
            <h3 className="text-lg font-bold tracking-tight text-slate-100 uppercase text-[13px] tracking-[0.1em]">On-Air AI Studio</h3>
          </div>
          <button 
            onClick={handleDJBreak}
            disabled={isTalking}
            className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] transition-all duration-300 transform active:scale-95 ${
              isTalking 
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700' 
              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20 border border-indigo-400/30'
            }`}
          >
            {isTalking ? 'Sinal no Ar' : 'Chamar DJ'}
          </button>
        </div>

        <div className="min-h-[70px] flex items-center justify-center border border-slate-700/50 rounded-xl p-5 bg-slate-950/40 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/5 via-transparent to-pink-500/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
          {isTalking ? (
            <p className="text-slate-200 text-sm italic text-center animate-in fade-in zoom-in duration-500 font-medium leading-relaxed max-w-lg">
              "{transcript}"
            </p>
          ) : (
            <div className="text-center">
              <p className="text-slate-500 text-[11px] font-mono uppercase tracking-widest mb-1">Módulo Virtual DJ Pronto</p>
              <p className="text-slate-600 text-[10px]">Aguardando solicitação para intervenção de voz...</p>
            </div>
          )}
        </div>
      </div>

      {/* Histórico de Falas (Console Log) */}
      <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl overflow-hidden shadow-inner">
        <div className="bg-slate-900/80 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg className="w-3 h-3 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
            </svg>
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">DJ Broadcast Log</span>
          </div>
          <span className="text-[9px] font-mono text-slate-600">v2.1_LATEST</span>
        </div>
        
        <div className="max-h-48 overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-slate-700">
          {history.length > 0 ? (
            history.map((entry, idx) => (
              <div 
                key={idx} 
                className={`flex gap-3 pb-3 ${idx !== history.length - 1 ? 'border-b border-slate-800/50' : ''} animate-in slide-in-from-top-1 duration-300`}
              >
                <div className="shrink-0 pt-1">
                  <span className="text-[9px] font-mono text-indigo-500/70 bg-indigo-500/10 px-1.5 py-0.5 rounded">
                    {entry.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="flex-1">
                  <p className="text-[12px] text-slate-400 font-mono leading-relaxed">
                    <span className="text-indigo-400/50 mr-1">&gt;</span>
                    {entry.text}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="py-4 text-center">
              <p className="text-[10px] text-slate-700 italic font-mono uppercase tracking-tighter">Nenhuma transmissão registrada nesta sessão</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
