
import { GoogleGenAI, Modality } from "@google/genai";

// Service for interacting with Google Gemini API models
export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // API key must be accessed directly from process.env.API_KEY and passed as a named parameter
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async generateDJIntro(stationName: string, genre: string): Promise<string> {
    const prompt = `Você é o DJ da rádio virtual "NovaStream".
    Atualmente a rádio está tocando a estação "${stationName}" (Gênero: ${genre}).
    Crie uma breve e empolgante fala de abertura de rádio (máximo 150 caracteres) dando as boas-vindas aos ouvintes e comentando sobre o clima musical atual. 
    Seja carismático, use gírias modernas do mundo da música e eletrônica.`;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });
      // The text property on GenerateContentResponse returns the generated text directly
      return response.text || "Bem-vindos à NovaStream, a batida que nunca dorme!";
    } catch (error) {
      console.error("Error generating DJ intro:", error);
      return "Sintonizados na melhor frequência, fiquem com a música!";
    }
  }

  async speakText(text: string, voice: string = 'Kore'): Promise<Uint8Array | null> {
    try {
      const response = await this.ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voice },
            },
          },
        },
      });

      // Extract raw PCM audio bytes from the response candidates
      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) return null;

      return this.decodeBase64(base64Audio);
    } catch (error) {
      console.error("TTS Error:", error);
      return null;
    }
  }

  // Implementation of base64 decoding following the recommended pattern
  private decodeBase64(base64: string): Uint8Array {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  }
}

export const geminiService = new GeminiService();
